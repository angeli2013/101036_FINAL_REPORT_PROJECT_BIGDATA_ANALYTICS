# generate_transactions.py

import json
import random
import datetime
import uuid

# ---------------- CONFIG ----------------
NUM_TRANSACTIONS = 20000

SESSIONS_FILE = "data/raw/sessions_0.json"
PRODUCTS_FILE = "data/raw/products.json"
OUTPUT_FILE = "data/raw/transactions.json"

# ---------------- LOAD DATA ----------------
with open(SESSIONS_FILE, "r") as f:
    sessions = json.load(f)

with open(PRODUCTS_FILE, "r") as f:
    products = json.load(f)

print("Sessions and products loaded")

# ---------------- GENERATE TRANSACTIONS ----------------
transactions = []

for _ in range(NUM_TRANSACTIONS):
    session = random.choice(sessions)
    product = random.choice(products)

    quantity = random.randint(1, 3)
    unit_price = product["base_price"]
    subtotal = round(quantity * unit_price, 2)

    discount = round(subtotal * random.choice([0, 0.05, 0.1]), 2)
    total = round(subtotal - discount, 2)

    transactions.append({
        "transaction_id": f"txn_{uuid.uuid4().hex[:12]}",
        "session_id": session["session_id"],      # ✅ FIXED
        "user_id": session["user_id"],             # ✅ CONSISTENT
        "timestamp": datetime.datetime.now().isoformat(),
        "items": [
            {
                "product_id": product["product_id"],
                "quantity": quantity,
                "unit_price": unit_price,
                "subtotal": subtotal
            }
        ],
        "subtotal": subtotal,
        "discount": discount,
        "total": total,
        "payment_method": random.choice(
            ["credit_card", "paypal", "bank_transfer"]
        ),
        "status": "completed"
    })

# ---------------- SAVE ----------------
with open(OUTPUT_FILE, "w") as f:
    json.dump(transactions, f, indent=2)

print("transactions.json generated WITH session_id!")
