## MongoDB Implementation

This folder contains the MongoDB-related implementation for the e-commerce project.

### Collections Used
- `users`: Stores user profiles and registration information
- `products`: Stores product catalog data
- `categories`: Stores category hierarchy
- `transactions`: Stores completed transaction documents with embedded line items

### Data Loading
Data was generated using Python scripts and imported into MongoDB using MongoDB Compass.

### Sample Queries
- Aggregate total spending per user
- Retrieve transaction history for a specific user
- Identify top-selling products

MongoDB was chosen for its flexible document model and efficient handling of transactional and catalog data.
