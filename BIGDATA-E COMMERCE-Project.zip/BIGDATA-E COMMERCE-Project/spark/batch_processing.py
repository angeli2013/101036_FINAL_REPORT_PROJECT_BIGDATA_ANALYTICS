# =====================================================
# Spark Batch Processing & SQL Analytics
# Big Data E-Commerce Project
# =====================================================
# This script demonstrates:
# 1. Batch data loading and cleaning
# 2. Cohort analysis of user purchasing behavior
# 3. Spark SQL analytics on JSON data
# =====================================================

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    to_date, 
    year, 
    month,
     count,
    sum as spark_sum  
)
# -----------------------------------------------------
# 1. Create Spark Session
# -----------------------------------------------------
spark = SparkSession.builder \
    .appName("Ecommerce Spark Batch Processing") \
    .getOrCreate()

spark.sparkContext.setLogLevel("WARN")

# -----------------------------------------------------
# 2. Load JSON Data (local filesystem)
# -----------------------------------------------------
BASE_PATH = "file:///C:/BIGDATA-E COMMERCE-Project/data/raw/"

transactions = spark.read.option("multiline", "true").json(
    BASE_PATH + "transactions.json"
)

users = spark.read.option("multiline", "true").json(
    BASE_PATH + "users.json"
)

# -----------------------------------------------------
# 3. Basic Data Inspection
# -----------------------------------------------------
print("Sample Transactions:")
transactions.show(5, truncate=False)

print("Transactions Schema:")
transactions.printSchema()

# -----------------------------------------------------
# 4. Data Cleaning & Preparation
# -----------------------------------------------------
# Convert timestamp strings to date
transactions_clean = transactions.withColumn(
    "transaction_date",
    to_date(col("timestamp"))
)

# Convert registration date to date
users_clean = users.withColumn(
    "registration_date",
    to_date(col("registration_date"))
)

# Create cohort attributes (year & month)
users_clean = users_clean.withColumn(
    "cohort_year",
    year(col("registration_date"))
).withColumn(
    "cohort_month",
    month(col("registration_date"))
)

# -----------------------------------------------------
# 5. Join Users and Transactions
# -----------------------------------------------------
user_transactions = transactions_clean.join(
    users_clean,
    on="user_id",
    how="inner"
)

# -----------------------------------------------------
# 6. Cohort Analysis (REQUIRED TASK)
# -----------------------------------------------------
cohort_analysis = user_transactions.groupBy(
    "cohort_year",
    "cohort_month"
).agg(
    count("transaction_id").alias("total_transactions"),
    spark_sum("total").alias("total_spent")
).orderBy(
    "cohort_year",
    "cohort_month"
)

print("Cohort Analysis Results:")
cohort_analysis.show(truncate=False)

# -----------------------------------------------------
# 7. Spark SQL Analytics
# -----------------------------------------------------
# Register temporary SQL views
transactions_clean.createOrReplaceTempView("transactions")
users_clean.createOrReplaceTempView("users")

# Example Spark SQL query:
# Total spending and transaction count per user
spark_sql_result = spark.sql("""
    SELECT
        t.user_id,
        COUNT(t.transaction_id) AS transaction_count,
        SUM(t.total) AS total_spent
    FROM transactions t
    GROUP BY t.user_id
    ORDER BY total_spent DESC
""")

print("Spark SQL Analytics Result:")
spark_sql_result.show(10, truncate=False)

# -----------------------------------------------------
# 8. Stop Spark Session
# -----------------------------------------------------
spark.stop()
