# =========================================================
# Integrated Analytics: Customer Lifetime Value (CLV)
# =========================================================

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col,
    to_date,
    count,
    sum as spark_sum
)

# ---------------------------------------------------------
# 1. Create Spark Session
# ---------------------------------------------------------
spark = SparkSession.builder \
    .appName("Integrated Analytics - CLV") \
    .getOrCreate()

# ---------------------------------------------------------
# 2. Load MongoDB-exported JSON data
# ---------------------------------------------------------
users = spark.read.option("multiline", "true").json(
    "file:///C:/BIGDATA-E COMMERCE-Project/data/raw/users.json"
)

transactions = spark.read.option("multiline", "true").json(
    "file:///C:/BIGDATA-E COMMERCE-Project/data/raw/transactions.json"
)

# ---------------------------------------------------------
# 3. Data Cleaning
# ---------------------------------------------------------
transactions = transactions.withColumn(
    "transaction_date",
    to_date(col("timestamp"))
)

# ---------------------------------------------------------
# 4. Join Users with Transactions
# ---------------------------------------------------------
user_transactions = users.join(
    transactions,
    users.user_id == transactions.user_id,
    "inner"
)

# ---------------------------------------------------------
# 5. CLV Aggregation
# ---------------------------------------------------------
clv_df = user_transactions.groupBy(
    users.user_id
).agg(
    count("transaction_id").alias("total_transactions"),
    spark_sum("total").alias("lifetime_value")
)

# ---------------------------------------------------------
# 6. Show Results
# ---------------------------------------------------------
clv_df.orderBy(
    col("lifetime_value").desc()
).show(10, truncate=False)

# ---------------------------------------------------------
# Stop Spark
# ---------------------------------------------------------
spark.stop()
