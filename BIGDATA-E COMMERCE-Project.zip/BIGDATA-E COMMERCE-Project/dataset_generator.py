# dataset_generator.py

import json
import random
import datetime
import uuid
import numpy as np
from faker import Faker

# --------------------------------------------------
# INITIAL SETUP
# --------------------------------------------------
fake = Faker()
np.random.seed(42)
random.seed(42)
Faker.seed(42)

# --------------------------------------------------
# CONFIGURATION (SAFE FOR LAPTOP)
# --------------------------------------------------
NUM_USERS = 1000
NUM_PRODUCTS = 1000
NUM_CATEGORIES = 25
NUM_SESSIONS = 10000
TIMESPAN_DAYS = 90

print("Initializing dataset generation...")

# --------------------------------------------------
# ID HELPERS
# --------------------------------------------------
def generate_session_id():
    return f"sess_{uuid.uuid4().hex[:10]}"

# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------
def determine_page_type(position, previous_pages):
    if position == 0:
        return random.choice(["home", "search", "category_listing"])

    prev = previous_pages[-1]["page_type"]
    transitions = {
        "home": ["category_listing", "search", "product_detail"],
        "category_listing": ["product_detail", "search", "home"],
        "search": ["product_detail", "category_listing", "home"],
        "product_detail": ["product_detail", "cart", "home"],
        "cart": ["checkout", "home"],
        "checkout": ["confirmation", "home"],
        "confirmation": ["home"]
    }
    return random.choice(transitions.get(prev, ["home"]))

def get_page_content(page_type, products, categories):
    if page_type == "product_detail":
        product = random.choice(products)
        category = next(c for c in categories if c["category_id"] == product["category_id"])
        return product, category
    if page_type == "category_listing":
        return None, random.choice(categories)
    return None, None

# --------------------------------------------------
# CATEGORY GENERATION
# --------------------------------------------------
categories = []
for i in range(NUM_CATEGORIES):
    category = {
        "category_id": f"cat_{i:03d}",
        "name": fake.company(),
        "subcategories": []
    }
    for j in range(random.randint(3, 5)):
        category["subcategories"].append({
            "subcategory_id": f"sub_{i:03d}_{j:02d}",
            "name": fake.bs(),
            "profit_margin": round(random.uniform(0.1, 0.4), 2)
        })
    categories.append(category)

print("Categories generated")

# --------------------------------------------------
# PRODUCT GENERATION
# --------------------------------------------------
products = []
product_date = datetime.datetime.now() - datetime.timedelta(days=TIMESPAN_DAYS * 2)

for i in range(NUM_PRODUCTS):
    category = random.choice(categories)
    subcategory = random.choice(category["subcategories"])   
    price = round(random.uniform(10, 500), 2)

    products.append({
        "product_id": f"prod_{i:05d}",
        "name": fake.catch_phrase().title(),
        "category_id": category["category_id"],
        "subcategory_id": subcategory["subcategory_id"],
        "base_price": price,
        "current_stock": random.randint(10, 500),
        "is_active": True,
        "price_history": [
            {
                "price": round(price * random.uniform(0.8, 1.1), 2),
                "date": product_date.isoformat()
            },
            {
                "price": price,
                "date": (product_date + datetime.timedelta(days=random.randint(10, 60))).isoformat()
            }
        ],
        "creation_date": product_date.isoformat()
    })

print("Products generated")
# --------------------------------------------------
# USER GENERATION
# --------------------------------------------------
users = []
for i in range(NUM_USERS):
    reg_date = fake.date_time_between(
        start_date=f"-{TIMESPAN_DAYS * 3}d",
        end_date=f"-{TIMESPAN_DAYS}d"
    )
    users.append({
        "user_id": f"user_{i:06d}",
        "geo_data": {
            "city": fake.city(),
            "state": fake.state_abbr(),
            "country": fake.country_code()
        },
        "registration_date": reg_date.isoformat(),
        "last_active": fake.date_time_between(start_date=reg_date, end_date="now").isoformat()
    })

print("Users generated")

# --------------------------------------------------
# SESSION GENERATION (TEACHER-COMPLIANT)
# --------------------------------------------------
sessions = []

for _ in range(NUM_SESSIONS):
    user = random.choice(users)
    session_id = generate_session_id()
    start_time = fake.date_time_between(
        start_date=f"-{TIMESPAN_DAYS}d",
        end_date="now"
    )
    duration_seconds = random.randint(30, 1800)

    page_views = []
    viewed_products = set()

    steps = random.randint(3, 10)
    for pos in range(steps):
        page_type = determine_page_type(pos, page_views)
        product, category = get_page_content(page_type, products, categories)

        if product:
            viewed_products.add(product["product_id"])

        page_views.append({
            "timestamp": (start_time + datetime.timedelta(seconds=pos * 60)).isoformat(),
            "page_type": page_type,
            "product_id": product["product_id"] if product else None,
            "category_id": category["category_id"] if category else None,
            "view_duration": random.randint(10, 120)
        })

    sessions.append({
        "session_id": session_id,
        "user_id": user["user_id"],
        "start_time": start_time.isoformat(),
        "end_time": (start_time + datetime.timedelta(seconds=duration_seconds)).isoformat(),
        "duration_seconds": duration_seconds,

        "geo_data": {
            "city": fake.city(),
            "state": fake.state_abbr(),
            "country": fake.country_code(),
            "ip_address": fake.ipv4()
        },

        "device_profile": {
            "type": random.choice(["mobile", "desktop", "tablet"]),
            "os": random.choice(["iOS", "Android", "Windows", "macOS"]),
            "browser": random.choice(["Chrome", "Safari", "Firefox", "Edge"])
        },

        "viewed_products": list(viewed_products),
        "page_views": page_views,

        "cart_contents": {
            pid: {
                "quantity": random.randint(1, 3),
                "price": round(random.uniform(20, 300), 2)
            }
            for pid in viewed_products
            if random.random() < 0.3
        },

        "conversion_status": "converted" if random.random() < 0.3 else "browsed",
        "referrer": random.choice(
            ["direct", "email", "social", "search_engine", "affiliate"]
        )
    })

print("Sessions generated")

# --------------------------------------------------
# SAVE FILES
# --------------------------------------------------
def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

save_json("data/raw/users.json", users)
save_json("data/raw/products.json", products)
save_json("data/raw/categories.json", categories)
save_json("data/raw/sessions_0.json", sessions)

print("Dataset generation complete!")
