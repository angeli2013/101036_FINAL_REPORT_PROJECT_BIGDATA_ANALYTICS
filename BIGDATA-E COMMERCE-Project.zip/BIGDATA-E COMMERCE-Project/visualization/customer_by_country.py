
# =====================================================
# Customers by Country (Full Country Names)
# Big Data E-Commerce Project
# =====================================================

import json
import pandas as pd
import matplotlib.pyplot as plt

# -----------------------------------------------------
# 1. Load users data
# -----------------------------------------------------
USERS_PATH = "C:/BIGDATA-E COMMERCE-Project/data/raw/users.json"

with open(USERS_PATH, "r") as f:
    users = json.load(f)

users_df = pd.DataFrame(users)

# -----------------------------------------------------
# 2. Extract country code
# -----------------------------------------------------
users_df["country_code"] = users_df["geo_data"].apply(
    lambda x: x.get("country", "Unknown") if isinstance(x, dict) else "Unknown"
)

# -----------------------------------------------------
# 3. Country code → full country name mapping
# -----------------------------------------------------
country_map = {
    "US": "United States",
    "FR": "France",
    "IN": "India",
    "DE": "Germany",
    "UK": "United Kingdom",
    "CN": "China",
    "JP": "Japan",
    "CA": "Canada",
    "BR": "Brazil",
    "AU": "Australia",
    "RW": "Rwanda"
}

users_df["country_name"] = users_df["country_code"].map(country_map).fillna("Other")

# -----------------------------------------------------
# 4. Aggregate customers per country
# -----------------------------------------------------
country_counts = (
    users_df["country_name"]
    .value_counts()
    .head(10)
)

# -----------------------------------------------------
# 5. Plot
# -----------------------------------------------------
plt.figure(figsize=(10, 6))
country_counts.plot(kind="bar", color="purple")

plt.title("Top Countries by Number of Customers")
plt.xlabel("Country")
plt.ylabel("Number of Customers")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

# -----------------------------------------------------
# 6. Save plot
# -----------------------------------------------------
OUTPUT_PATH = "C:/BIGDATA-E COMMERCE-Project/report/images/customer_by_country.png"
plt.savefig(OUTPUT_PATH)
plt.close()

print("Customer by country visualization saved successfully.")
