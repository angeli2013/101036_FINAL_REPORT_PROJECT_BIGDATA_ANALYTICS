import pandas as pd
import matplotlib.pyplot as plt

# Load transactions data
transactions = pd.read_json(
    "C:/BIGDATA-E COMMERCE-Project/data/raw/transactions.json"
)

# Convert timestamp
transactions["timestamp"] = pd.to_datetime(transactions["timestamp"])

# Create year-month column
transactions["year_month"] = transactions["timestamp"].dt.to_period("M")

# Aggregate sales per month
sales_over_time = transactions.groupby("year_month")["total"].sum()

# Convert Period to string for plotting
sales_over_time.index = sales_over_time.index.astype(str)

# Plot
plt.figure(figsize=(10,5))
plt.plot(sales_over_time.index, sales_over_time.values, marker="o")
plt.title("Sales Performance Over Time (Monthly)")
plt.xlabel("Year-Month")
plt.ylabel("Total Sales")
plt.xticks(rotation=45)
plt.tight_layout()

# Save image
plt.savefig("C:/BIGDATA-E COMMERCE-Project/report/images/sales_over_time.png")
plt.close()
