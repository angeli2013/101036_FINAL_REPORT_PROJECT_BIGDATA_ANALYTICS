# =====================================================
# CLV Distribution Visualization
# Big Data E-Commerce Project
# =====================================================

import json
import pandas as pd
import matplotlib.pyplot as plt

# -----------------------------------------------------
# 1. Load transactions data
# -----------------------------------------------------
TX_PATH = "C:/BIGDATA-E COMMERCE-Project/data/raw/transactions.json"

with open(TX_PATH, "r") as f:
    transactions = json.load(f)

# -----------------------------------------------------
# 2. Compute CLV per user
# -----------------------------------------------------
rows = []

for tx in transactions:
    rows.append({
        "user_id": tx["user_id"],
        "total": tx["total"]
    })

df = pd.DataFrame(rows)

clv_df = df.groupby("user_id")["total"].sum().reset_index()
clv_df.rename(columns={"total": "clv"}, inplace=True)

# -----------------------------------------------------
# 3. Plot CLV distribution
# -----------------------------------------------------
plt.figure(figsize=(10, 6))
plt.hist(clv_df["clv"], bins=30, color="green", edgecolor="black")

plt.title("Customer Lifetime Value (CLV) Distribution")
plt.xlabel("Customer Lifetime Value")
plt.ylabel("Number of Customers")
plt.tight_layout()

# -----------------------------------------------------
# 4. Save plot
# -----------------------------------------------------
OUTPUT_PATH = "C:/BIGDATA-E COMMERCE-Project/report/images/clv_distribution.png"
plt.savefig(OUTPUT_PATH)
plt.close()

print("CLV distribution saved successfully.")
