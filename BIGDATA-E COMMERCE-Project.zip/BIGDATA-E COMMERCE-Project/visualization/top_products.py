# =====================================================
# Top Products Visualization (With Product Names)
# Big Data E-Commerce Project
# =====================================================

import pandas as pd
import matplotlib.pyplot as plt
import json

# -----------------------------------------------------
# 1. Load transactions
# -----------------------------------------------------
TX_PATH = "C:/BIGDATA-E COMMERCE-Project/data/raw/transactions.json"

with open(TX_PATH, "r") as f:
    transactions = json.load(f)

# -----------------------------------------------------
# 2. Load products catalog
# -----------------------------------------------------
PRODUCTS_PATH = "C:/BIGDATA-E COMMERCE-Project/data/raw/products.json"

with open(PRODUCTS_PATH, "r") as f:
    products = json.load(f)

products_df = pd.DataFrame(products)[["product_id", "name"]]

# -----------------------------------------------------
# 3. Flatten transaction items
# -----------------------------------------------------
rows = []

for tx in transactions:
    for item in tx["items"]:
        rows.append({
            "product_id": item["product_id"],
            "item_subtotal": item["subtotal"]
        })

sales_df = pd.DataFrame(rows)

# -----------------------------------------------------
# 4. Aggregate total revenue per product
# -----------------------------------------------------
top_sales = (
    sales_df.groupby("product_id")["item_subtotal"]
    .sum()
    .reset_index()
)

# -----------------------------------------------------
# 5. Join with product names
# -----------------------------------------------------
top_sales_named = top_sales.merge(
    products_df,
    on="product_id",
    how="left"
)

top_products = (
    top_sales_named
    .sort_values("item_subtotal", ascending=False)
    .head(10)
)

# -----------------------------------------------------
# 6. Plot (FIXED)
# -----------------------------------------------------
plt.figure(figsize=(12, 6))
plt.bar(
    top_products["name"],           # ✅ correct column
    top_products["item_subtotal"],  # ✅ correct column
    color="red"
)

plt.title("Top 10 Products by Total Revenue")
plt.xlabel("Product Name")
plt.ylabel("Total Revenue")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()

# -----------------------------------------------------
# 7. Save plot
# -----------------------------------------------------
OUTPUT_PATH = "C:/BIGDATA-E COMMERCE-Project/report/images/top_products.png"
plt.savefig(OUTPUT_PATH)
plt.close()

print("Top products (with names) visualization saved successfully.")
